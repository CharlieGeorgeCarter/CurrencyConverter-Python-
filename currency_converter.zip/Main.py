#!/usr/bin/python3
import os
import sys
import tkinter as tkinter #imports tkninter so we can do some graphic work
from tkinter import *
import WebScraper #imports the webscraper to scrape the european central bank website for the currencies they support
# note that module name has changed from Tkinter in Python 2 to tkinter in Python 3
from currency_converter import CurrencyConverter #pulls latest conversion rates from European Central Bank
#--------------------------------------------------------------------------------------------------------------------------------------
#SETS UP THE TKINTER WINDOW AND BACKGROUND FOR THE WINDOWS
self = tkinter.Tk() #self is set to a Tkinter Window#
self.geometry('800x400')
self.winfo_toplevel().title("Currency Converter")
Converter = CurrencyConverter() #shorthands the CurrencyConverter function from Currency_Converter to c
BackgroundImage = str(os.path.join(sys.path[0])+'\\'+"CanvasBackground.png")
filename = PhotoImage(file = BackgroundImage)
background_label = Label(self, image=filename)
background_label.place(x=0, y=0)
#--------------------------------------------------------------------------------------------------------------------------------------
#CALLTS THE SCRAPECURRENCIES COMAND FROM WEBSCRAPER TO GET AVAILABLE CURREMCIES
WebScraper.ScrapeCurrencies()
#--------------------------------------------------------------------------------------------------------------------------------------
#CREATES THE DROP DOWN MENU FOR CURRENCY SELECTIONS
FromPreText = tkinter.StringVar(self)
FromPreText.set(WebScraper.CurrencyList[0])
FromCurrencyDropBox = tkinter.OptionMenu(self, FromPreText, *WebScraper.CurrencyList)
FromCurrencyDropBox.config(width=10, font=('Helvetica', 12))
FromCurrencyDropBox.pack()
FromCurrencyDropBox.place(x=340, y= 155)
FromLabel = Label(text="USD", font=('Helvetica',12))
FromLabel.pack()
FromLabel.place(x=470,y=230)
def callback(*args):
   FromLabel.configure(text=FromPreText.get())
FromPreText.trace("w",callback)

ToPreText = tkinter.StringVar(self)
ToPreText.set(WebScraper.CurrencyList[0])
ToCurrencyDropBox = tkinter.OptionMenu(self, ToPreText, *WebScraper.CurrencyList)
ToCurrencyDropBox.config(width=10, font=('Helvetica', 12))
ToCurrencyDropBox.pack()
ToCurrencyDropBox.place(x=600, y= 155)
ToLabel = Label(text="USD", font=('Helvetica',12))
ToLabel.pack()
ToLabel.place(x=720,y=230)
def callback(*args):
   ToLabel.configure(text=ToPreText.get())
ToPreText.trace("w",callback)
#--------------------------------------------------------------------------------------------------------------------------------------
#CREATES THE TEXTBOX FOR THE CURRENCY AMOUNT INPUT
AmountInput = tkinter.Entry(self,width=15, font=('Helvetica',12))
AmountInput.pack()
AmountInput.place(x=60,y=160)
#--------------------------------------------------------------------------------------------------------------------------------------
#CREATES AND HANDLES BUTTON BEHAVOIR / CURRENCY CONVERSION
def ConvertCurrency():
    Conversion = Converter.convert(float(AmountInput.get()),str(FromLabel.cget("text")),str(ToLabel.cget("text")))
    ConversionFortmatted = float("{:.2f}".format(Conversion))
    print(Conversion)
    ConvertedAmountLabel = Label(text=FromLabel.cget("text")+" Converted To "+ToLabel.cget("text")+" Is "+ str(ConversionFortmatted),font=('Helvetica', 12))
    ConvertedAmountLabel.pack()
    ConvertedAmountLabel.place(x=270,y=350)

ButtonPhoto = str(os.path.join(sys.path[0])+'\\'+"ConvertButton.png")
ButtonFileName= PhotoImage(file = ButtonPhoto)
ConvertButton = Button(self, text="", image=ButtonFileName, command=ConvertCurrency)
ConvertButton.pack()
ConvertButton.place(x=350,y=300)
#--------------------------------------------------------------------------------------------------------------------------------------
#CONVERTED LABEL & OUTPUT
#ConvertedAmountLabel = Label(text=FromLabel.cget("text")+" Converted To "+ToLabel.cget("text")+" Is "+ ConvertCurrency.Conversion)
#--------------------------------------------------------------------------------------------------------------------------------------
self.mainloop()

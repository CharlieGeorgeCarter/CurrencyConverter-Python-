#To be used for web scraping using beautiful soup
#requires beautifulsoup4

from bs4 import BeautifulSoup
import requests
CurrencyList = []
URL = "https://www.ecb.europa.eu/stats/policy_and_exchange_rates/euro_reference_exchange_rates/html/index.en.html"
Html_Page = requests.get(URL)
soup = BeautifulSoup(Html_Page.content, "html.parser") # If this line causes an error, run 'pip install html5lib' or install html5lib


def ScrapeCurrencies():
    Rows = soup.find("table").find("tbody").find_all("tr")
    for Row in Rows:
        cells = Row.find_all("td")
        ReturnCells = cells[0].get_text()
        CurrencyList.append(ReturnCells)
